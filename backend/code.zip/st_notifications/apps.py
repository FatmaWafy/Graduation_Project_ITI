from django.apps import AppConfig


class StNotificationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'st_notifications'
